<!DOCTYPE html>
<html lang="pt">
  <head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="socket.io/socket.io.js"></script>
    <script src="script.js"></script>

    <style>
      body {
        height: 100vh;
        width: 100%;
        background: linear-gradient(to bottom, #175d69 23%, #330c43 95%);
        overflow: hidden;
        margin: 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        color: white;
      }

      .board {
        margin: auto;
        width: 490px;
      }

      .board button {
        height: 150px;
        width: 150px;
        float: left;
        margin: 5px;
        font-size: 3em;
      }

      #message {
        font-size: 3rem;
        margin-bottom: 1rem;
        text-align: center;
      }

      #player1,
      #player2 {
        font-size: 1.5rem;
        text-align: center;
        margin-bottom: 10px;
      }

      .player-input {
        width: 150px;
        margin: 5px;
        padding: 5px;
        font-size: 1rem;
      }

      a {
        display: block;
        text-align: center;
        margin-top: 20px;
        color: white;
        text-decoration: none;
        background-color: #4CAF50;
        padding: 10px 20px;
        border-radius: 5px;
        transition: background-color 0.3s;
      }

      a:hover {
        background-color: #45a049;
      }
    </style>
  </head>

  <body>
    <h1>Jogo do Galo Online</h1>
    <div id="message">A espera de adversario</div>

    <div class="board">
      <button id="r0c0"></button> <button id="r0c1"></button>
      <button id="r0c2"></button> <button id="r1c0"></button>
      <button id="r1c1"></button> <button id="r1c2"></button>
      <button id="r2c0"></button> <button id="r2c1"></button>
      <button id="r2c2"></button>
    </div>

    <a href="http://18.130.148.242/HTML/Jogos.html">Voltar</a>
  </body>
</html>
