<?php
class User{
    protected $db;
    protected $user_name;
    protected $user_email;
    protected $user_pass;
    protected $hash_pass;
    
    function __construct($db_connection){
        $this->db = $db_connection;
    }

    //Registar
    function singUpUser($username, $user_email, $user_password){
        try{
            $this->user_name = trim($username);
            $this->user_email = trim($user_email);
            $this->user_pass = trim($user_password);
            if(!empty($this->user_name) && !empty($this->user_email) && !empty($this->user_pass)){

                if (filter_var($this->user_email, FILTER_VALIDATE_EMAIL)) { 
                    $check_email = $this->db->prepare("SELECT * FROM `users` WHERE user_email = ?");
                    $check_email->execute([$this->user_email]);

                    if($check_email->rowCount() > 0){
                        return ['errorMessage' => 'Este Email ja está em uso. Faça login ou tente outro.'];
                    }
                    else{
                        
                        $user_image = "default";

                        $this->hash_pass = password_hash($this->user_pass, PASSWORD_DEFAULT);
                        $sql = "INSERT INTO `users` (username, user_email, user_password, user_image) VALUES(:username, :user_email, :user_pass, :user_image)";
            
                        $sign_up_stmt = $this->db->prepare($sql);
                        //BIND VALUES
                        $sign_up_stmt->bindValue(':username',htmlspecialchars($this->user_name), PDO::PARAM_STR);
                        $sign_up_stmt->bindValue(':user_email',$this->user_email, PDO::PARAM_STR);
                        $sign_up_stmt->bindValue(':user_pass',$this->hash_pass, PDO::PARAM_STR);
                        // INSERTING RANDOM IMAGE NAME
                        $sign_up_stmt->bindValue(':user_image',$user_image.'.jpg', PDO::PARAM_STR);
                        $sign_up_stmt->execute();
                        return ['successMessage' => 'Registo efetuado'];                   
                    }
                }
                else{
                    return ['errorMessage' => 'Email invalido'];
                }    
            }
            else{
                return ['errorMessage' => 'Por favor preencha todos os campos'];
            } 
        }
        catch (PDOException $e) {
            die($e->getMessage());
        }
    }

    //Login
    function loginUser($user_email, $user_password){
        
        try{
            $this->user_email = trim($user_email);
            $this->user_pass = trim($user_password);

            $find_email = $this->db->prepare("SELECT * FROM `users` WHERE user_email = ?");
            $find_email->execute([$this->user_email]);
            
            if($find_email->rowCount() === 1){
                $row = $find_email->fetch(PDO::FETCH_ASSOC);

                $match_pass = password_verify($this->user_pass, $row['user_password']);
                if($match_pass){
                    $_SESSION = [
                        'user_id' => $row['id'],
                        'email' => $row['user_email']
                    ];
                    header('Location: profile.php');
                }
                else{
                    return ['errorMessage' => 'Password Invalida'];
                }
                
            }
            else{
                return ['errorMessage' => 'Email Invalido'];
            }

        }
        catch (PDOException $e) {
            die($e->getMessage());
        }

    }

    // find user by id para relacionar com o id do utilizador, verificar amigos, etc.
    function find_user_by_id($id){
        try{
            $find_user = $this->db->prepare("SELECT * FROM `users` WHERE id = ?");
            $find_user->execute([$id]);
            if($find_user->rowCount() === 1){
                return $find_user->fetch(PDO::FETCH_OBJ);
            }
            else{
                return false;
            }
        }
        catch (PDOException $e) {
            die($e->getMessage());
        }
    }
    
    //Todos os utilizadores cujo id é diferente do id do utilizador logado
    function all_users($id){
        try{
            $get_users = $this->db->prepare("SELECT id, username, user_image FROM `users` WHERE id != ?");
            $get_users->execute([$id]);
            if($get_users->rowCount() > 0){
                return $get_users->fetchAll(PDO::FETCH_OBJ);
            }
            else{
                return false;
            }
        }
        catch (PDOException $e) {
            die($e->getMessage());
        }
    }

    public function update_profile_image($user_id, $profile_image)
    {
        $query = "UPDATE users SET user_image = :profile_image WHERE id = :user_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':profile_image', $profile_image, PDO::PARAM_STR);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);

        return $stmt->execute();
    }

    public function update_background_image($user_id, $background_image) {
        $query = "UPDATE users SET background_image = :background_image WHERE id = :user_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':background_image', $background_image, PDO::PARAM_STR);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);

        return $stmt->execute();
    }
        
}
?>