<?php
if(!session_id()) session_start();

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = ' users';

try {
    $_db = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass, array(PDO::ATTR_PERSISTENT => true, PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'", PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
} catch (Exception $e) {
    die('Unable to connect to database: '. $e->getMessage());
}
?>