<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enviar Imagen</title>
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap");

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(to bottom, #175d69 23%, #330c43 95%);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input[type="file"] {
            margin-bottom: 16px;
        }

        input[type="submit"] {
            background-color: #47b2e4;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #3887a3;
        }

        .back-link {
            margin-top: 20px;
        }

        .back-link a {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
        }
    </style>
</head>
<body>

    <form action="updatePics.php" method="post" enctype="multipart/form-data">
        <label for="profile_image">Alterar Imagem de Perfil:</label>
        <input type="file" name="profile_image" id="profile_image">
        <br>
        <label for="gradient_start">Cor de Início do Gradiente:</label>
        <input type="color" name="gradient_start" id="gradient_start">
        <br>

        <label for="gradient_end">Cor de Fim do Gradiente:</label>
        <input type="color" name="gradient_end" id="gradient_end">
        <br>

        <input type="submit" value="Atualizar Imagens" >
    </form>
    
    <div class="back-link">
        <a href="./profile.php">Voltar</a>
    </div>

</body>
</html>
