<?php
require '../includes/init.php';

if(isset($_POST['username']) && isset($_POST['email']) && isset($_POST['password'])){
  $result = $user_obj->singUpUser($_POST['username'],$_POST['email'],$_POST['password']);
}

if(isset($_SESSION['email'])){
  header('Location: profile.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap");
body, html {
    margin: 0;
    padding: 0;
    font-family: "Poppins", sans-serif;
    height: 100vh;
  width: 100%;
  background: linear-gradient(to bottom, #175d69 23%, #330c43 95%);
}

.main_container {
    max-width: 400px;
    margin: 50px auto;
    padding: 20px;
    background-color: #f4f4f4;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

form {
    display: flex;
    flex-direction: column;
}

label {
    margin-bottom: 5px;
    font-weight: bold;
}

input {
    margin-bottom: 15px;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 3px;
    box-sizing: border-box;
    width: 100%;
}

input[type="submit"] {
    background-color: #3498db;
    color: #fff;
    cursor: pointer;
}

.errorMsg, .successMsg {
    margin-top: 10px;
    padding: 10px;
    border-radius: 3px;
}

.errorMsg {
    background-color: #e74c3c;
    color: #fff;
}

.successMsg {
    background-color: #2ecc71;
    color: #fff;
}


.form_link {
    text-align: center;
    margin-top: 10px;
    color: #3498db;
    text-decoration: none;
}

a {
    display: block;
    text-align: center;
    margin-top: 20px;
    color: #3498db;
    text-decoration: none;
}
    </style>
</head>
<body>
  
  <div class="main_container">
    <h1>Sign Up</h1>
    <form action="" method="POST" novalidate>
      <label for="username">Nome Completo</label>
      <input type="text" id="username" name="username" spellcheck="false" placeholder="Nome Completo" required>
      <label for="email">Email</label>
      <input type="email" id="email" name="email" spellcheck="false" placeholder="Email" required>
      <label for="password">Password</label>
      <input type="password" id="password" name="password" placeholder="Password" required>
      <input type="submit" value="Registar">
      <a href="login.php" class="form_link">Já possui uma conta? Fazer Login</a>
    </form>
    <div>  
      <?php
        if(isset($result['errorMessage'])){
          echo '<p class="errorMsg">'.$result['errorMessage'].'</p>';
        }
        if(isset($result['successMessage'])){
          echo '<p class="successMsg">'.$result['successMessage'].'</p>';
        }
      ?>    
    </div>
    
  </div>
</body>
</html>

