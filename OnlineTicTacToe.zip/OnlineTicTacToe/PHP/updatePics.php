<?php
require '../includes/init.php';

if (isset($_SESSION['user_id']) && isset($_SESSION['email'])) {
    $user_data = $user_obj->find_user_by_id($_SESSION['user_id']);
    if ($user_data === false) {
        header('Location: logout.php');
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == UPLOAD_ERR_OK) {
            $uploadDir = 'profile_images/';
            $profileImageName = basename($_FILES['profile_image']['name']);
            $profileImagePath = $uploadDir . $profileImageName;
            move_uploaded_file($_FILES['profile_image']['tmp_name'], $profileImagePath);

            $user_obj->update_profile_image($_SESSION['user_id'], $profileImageName);
        }

        if (isset($_FILES['background_image']) && $_FILES['background_image']['error'] == UPLOAD_ERR_OK) {
            $uploadDir = 'profile_images/';
            $backgroundImageName = basename($_FILES['background_image']['name']);
            $backgroundImagePath = $uploadDir . $backgroundImageName;
            move_uploaded_file($_FILES['background_image']['tmp_name'], $backgroundImagePath);
        
            $gradientStart = isset($_POST['gradient_start']) ? $_POST['gradient_start'] : '#175d69';
            $gradientEnd = isset($_POST['gradient_end']) ? $_POST['gradient_end'] : '#330c43';
        
            $dbHost = "localhost";
            $dbUser = "root";
            $dbPassword = "";
            $dbName = "users";
        
            $conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);
        
            if ($conn->connect_error) {
                die("Erro de conexão: " . $conn->connect_error);
            }

            $checkUserQuery = "SELECT * FROM users WHERE id = $userId";
            $result = $conn->query($checkUserQuery);
        
            if ($result->num_rows > 0) {

                $updateQuery = "UPDATE users SET gradient_start = '$gradientStart', gradient_end = '$gradientEnd' WHERE id = $userId";
                $conn->query($updateQuery);
            } else {

                $insertQuery = "INSERT INTO users (id, gradient_start, gradient_end) VALUES ($userId, '$gradientStart', '$gradientEnd')";
                $conn->query($insertQuery);
            }
        
            $conn->close();
        
            echo "Gradient Start: $gradientStart<br>";
            echo "Gradient End: $gradientEnd<br>";
        }
        
} else {
    header('Location: profile.php');
    exit();
}
}
?>