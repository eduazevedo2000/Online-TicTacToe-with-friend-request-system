<?php
require 'includes/init.php';
//function para direcionar para o perfil
function redirect_to_profile(){
    header('Location: profile.php');
    exit;
}
//if para ter parametros e a 'action'
if(isset($_GET['action']) && isset($_GET['id'])){
    //ver se user está logado ou nao.  se estiver logado
    if(isset($_SESSION['user_id']) && isset($_SESSION['email'])){
        // se o parametro id for igual a ($_SESSION['user_id']), redirecionar para o perfil
        if($_GET['id'] == $_SESSION['user_id']){
            redirect_to_profile();
        }
        // se o parametro id for diferente a ($_SESSION['user_id']), ver se o utilizador é amigo ou não.
        else{
            //definir uma variavel para receber o id do utilizador
            $user_id = $_GET['id'];
            $my_id = $_SESSION['user_id'];

            //if para obter o request_status do utilizador
            if($_GET['action'] == 'send_req'){
                //ver se o request ja foi enviado 
                // is_request_already_sent() esta função retorna falso ou verdadeiro
                if($frnd_obj->is_request_already_sent($my_id, $user_id)){
                    redirect_to_profile();
                }
                // ver se este id ja esta na friendlist do utilizador
                //tambem devolve falso ou verdadeiro
                elseif($frnd_obj->is_already_friends($my_id, $user_id)){
                    redirect_to_profile();
                }
                //senao, enviar o request
                else{
                    $frnd_obj->make_pending_friends($my_id, $user_id);
                }
            }
            //if a acao cancelar o request ou ignorar o request
            else if($_GET['action'] == 'cancel_req' || $_GET['action'] == 'ignore_req'){
                $frnd_obj->cancel_or_ignore_friend_request($my_id, $user_id);
            }
            //if aceitar o request
            elseif($_GET['action'] == 'accept_req'){

                if($frnd_obj->is_already_friends($my_id, $user_id)){
                    redirect_to_profile();
                }
                else{
                    $frnd_obj->make_friends($my_id, $user_id);
                }
            }
            //if cancelar amizade
            elseif($_GET['action'] == 'unfriend_req'){
                $frnd_obj->delete_friends($my_id, $user_id);
            }
            else{
                redirect_to_profile();
            }
        }
    }
    else{
        header('Location: logout.php');
        exit;
    }
}
else{
    redirect_to_profile();
}